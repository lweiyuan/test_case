#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
author:      weiyuan1
date:        2026.09.07
description: tx_sched cos 测试基类，nic800 linux driver tx_scheduler 模块 cos 类用例脚本的二级基类
"""

import add_syspath

from scripts.script_libs import log
from scripts.script_libs.script_base import ScriptBase
from scripts.script_libs.common_operation import CommonOperation
from scripts.script_libs.command_operation import CommandOperation
from scripts.script_libs.enums import CmdExecuteAdressEnum, RtnStatusEnum

import argparse
import re
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum


class EtsAlgorithm(Enum):
    ETS = "ets"
    STRICT = "strict"
    HYBRID = "hybrid"


@dataclass
class TcConfig:
    tc_id: int  # TC 编号 (0-7)
    weight: int  # ETS 带宽百分比 (0-100)
    is_strict: bool = False  # 是否开启 Strict Priority
    max_rate_kbps: int = 0  # 限速速率 (Kbps)


@dataclass
class DcbState:
    """快照数据结构，用于失败回滚"""
    algo: EtsAlgorithm
    tc_configs: list[TcConfig] = field(default_factory=list)
    prio_dscp_bindings: list[tuple[int, int]] = field(default_factory=list)


class DcbEtsTcManager(ABC):
    """
    dcb ets 修改 tc 虚基类：将 tx_sched cos 用例中 dcb/ets 修改 tc 的步骤抽象为模板方法，
    子类按测试机环境实现具体命令下发，基类负责步骤编排与失败回滚。
    """

    def __init__(self, ifname: str):
        self.ifname = ifname

    @abstractmethod
    def get_max_supported_tcs(self) -> int:
        """步骤1：检查网卡支持的 tc 数量"""
        pass

    @abstractmethod
    def get_current_state(self) -> DcbState:
        """备份当前 dcb 配置快照"""
        pass

    @abstractmethod
    def restore_state(self, state: DcbState) -> bool:
        """按快照回滚 dcb 配置"""
        pass

    @abstractmethod
    def set_dcbx_host_ieee(self) -> bool:
        """步骤2：设置 dcbx host ieee"""
        pass

    @abstractmethod
    def configure_ets_tc(self, algo: EtsAlgorithm, tc_configs: list[TcConfig]) -> bool:
        """步骤4：dcb ets 设置带宽比例（tc-tsa 算法 + tc-bw 权重）"""
        pass

    @abstractmethod
    def show_ets(self) -> str:
        """步骤5：查询 dcb ets show dev，返回输出文本用于校验"""
        pass

    @abstractmethod
    def set_tc_max_rate(self, tc_id: int, max_rate_kbps: int) -> bool:
        """步骤7：对 tc 设置限速"""
        pass

    @abstractmethod
    def bind_priority_to_dscp(self, prio: int, dscp: int) -> bool:
        """步骤8：tc app 绑定优先级与 tos(dscp)"""
        pass

    def apply_dcb_configuration(
            self,
            algo: EtsAlgorithm,
            tc_configs: list[TcConfig],
            prio: int,
            dscp: int
    ) -> bool:
        """模板方法：按用例步骤编排 dcb ets 修改 tc 全流程，任一环节失败自动回滚"""
        try:
            snapshot = self.get_current_state()
            log.info(f"[Backup] 网卡 {self.ifname} 状态备份完成")
        except Exception as e:
            log.error(f"[Error] 读取网卡配置失败: {e}")
            return False

        try:
            # 步骤2: 设置 dcbx host ieee
            if not self.set_dcbx_host_ieee():
                raise RuntimeError("设置 dcbx host ieee 失败")

            # 步骤1: 检查测试网卡支持的 TC 数
            max_supported = self.get_max_supported_tcs()
            if len(tc_configs) > max_supported:
                raise ValueError(f"设置的 TC 数 ({len(tc_configs)}) 超过网卡上限 ({max_supported})")

            # 步骤4: 设置 ETS/Strict 算法与带宽分配
            if not self.configure_ets_tc(algo, tc_configs):
                raise RuntimeError("ETS/Strict 算法与带宽配置失败")

            # 步骤5: 查询 dcb ets show dev 校验下发结果
            ets_output = self.show_ets()
            if not ets_output:
                raise RuntimeError("查询 dcb ets show dev 失败")
            log.info(f"[Query] dcb ets show dev 结果:\n{ets_output}")

            # 步骤7: 设置 TC 限速 (Max Rate)
            for tc in tc_configs:
                if tc.max_rate_kbps > 0:
                    if not self.set_tc_max_rate(tc.tc_id, tc.max_rate_kbps):
                        raise RuntimeError(f"TC {tc.tc_id} 限速设置失败")

            # 步骤8: 执行 dcb app 指令进行 prio 与 dscp 绑定
            if not self.bind_priority_to_dscp(prio, dscp):
                raise RuntimeError(f"Priority {prio} 与 DSCP {dscp} 绑定失败")

            log.info(f"[Success] 网卡 {self.ifname} DCB 配置下发完毕！")
            return True

        except Exception as e:
            log.error(f"\n[ALERT] 配置异常: {e}")
            log.error("[Rollback] 开始自动回滚状态...")
            self.restore_state(snapshot)
            return False


class LinuxDcbCmdManager(DcbEtsTcManager):
    """通过框架 ssh 通道在测试机上执行 dcb 命令的 Linux 实现"""

    def __init__(self, ifname: str, cmd_execute_address: str = CmdExecuteAdressEnum.SERVER.value):
        super().__init__(ifname)
        self.cmd_execute_address = cmd_execute_address

    def run_cmd(self, cmd: str) -> bool:
        log.info(f"[Exec] {cmd}")
        cmd_code, cmd_output, cmd_stderr = CommandOperation.execute_command_based_paramiko_with_rtncode(
            cmd, cmd_execute_address=self.cmd_execute_address)
        if cmd_code != RtnStatusEnum.SUCCESS.value:
            log.error(f"[Failed] {cmd}\nstderr: {cmd_stderr}")
            return False
        if cmd_output:
            log.info(f"[Output] {cmd_output}")
        return True

    def set_dcbx_host_ieee(self) -> bool:
        return self.run_cmd(f"dcb dcbx set dev {self.ifname} host ieee")

    def show_ets(self) -> str:
        cmd = f"dcb ets show dev {self.ifname}"
        log.info(f"[Exec] {cmd}")
        cmd_code, cmd_output, cmd_stderr = CommandOperation.execute_command_based_paramiko_with_rtncode(
            cmd, cmd_execute_address=self.cmd_execute_address)
        if cmd_code != RtnStatusEnum.SUCCESS.value:
            log.error(f"[Failed] {cmd}\nstderr: {cmd_stderr}")
            return ""
        return cmd_output

    def get_max_supported_tcs(self) -> int:
        output = self.show_ets()
        match = re.search(r"tc-bw\s+((?:\d+:\d+\s*)+)", output)
        if match:
            count = len(match.group(1).strip().split())
            if count > 0:
                return count
        return 8

    def get_current_state(self) -> DcbState:
        output = self.show_ets()
        tc_bw: dict[int, int] = {}
        tc_tsa: dict[int, str] = {}
        for line in output.splitlines():
            line = line.strip()
            if line.startswith("tc-bw"):
                for pair in line.split()[1:]:
                    tc_id, bw = pair.split(":")
                    tc_bw[int(tc_id)] = int(bw)
            elif line.startswith("tc-tsa"):
                for pair in line.split()[1:]:
                    tc_id, tsa = pair.split(":")
                    tc_tsa[int(tc_id)] = tsa
        tc_configs = [
            TcConfig(tc_id=tc_id, weight=tc_bw[tc_id],
                     is_strict=tc_tsa.get(tc_id, "ets") == "strict")
            for tc_id in sorted(tc_bw)
        ]
        tsa_values = set(tc_tsa.values())
        if tsa_values == {"strict"}:
            algo = EtsAlgorithm.STRICT
        elif tsa_values == {"ets"}:
            algo = EtsAlgorithm.ETS
        else:
            algo = EtsAlgorithm.HYBRID
        return DcbState(algo=algo, tc_configs=tc_configs)

    def restore_state(self, state: DcbState) -> bool:
        if not state.tc_configs:
            log.warning("[Restore] 快照为空，跳过回滚")
            return True
        log.info(f"[Restore] 按快照回滚网卡 {self.ifname} 的 dcb ets 配置")
        return self.configure_ets_tc(state.algo, state.tc_configs)

    def configure_ets_tc(self, algo: EtsAlgorithm, tc_configs: list[TcConfig]) -> bool:
        tsa_cmd = f"dcb ets set dev {self.ifname} tc-tsa"
        bw_pairs = []
        for tc in tc_configs:
            tsa_cmd += f" {tc.tc_id}:{'strict' if tc.is_strict else 'ets'}"
            if not tc.is_strict:
                bw_pairs.append(f"{tc.tc_id}:{tc.weight}")
        if not self.run_cmd(tsa_cmd):
            return False
        if algo != EtsAlgorithm.STRICT and bw_pairs:
            if not self.run_cmd(f"dcb ets set dev {self.ifname} tc-bw " + " ".join(bw_pairs)):
                return False
        return True

    def set_tc_max_rate(self, tc_id: int, max_rate_kbps: int) -> bool:
        return self.run_cmd(f"dcb maxrate set dev {self.ifname} tc {tc_id}:{max_rate_kbps}Kbit")

    def bind_priority_to_dscp(self, prio: int, dscp: int) -> bool:
        return self.run_cmd(f"dcb app add dev {self.ifname} dscp {dscp} pcp {prio}")


# =========================================================================
# 参数校验与构建模块
# =========================================================================
def parse_and_validate_args():
    parser = argparse.ArgumentParser(description="DCB ETS TC 传参配置工具")

    # 基础参数
    parser.add_argument("-i", "--ifname", type=str, required=True, help="网卡接口名称 (例如 eth0)")
    parser.add_argument("-n", "--num-tcs", type=int, required=True, help="需要配置的 TC 数量 (1-8)")
    parser.add_argument("-a", "--algo", type=str, choices=["ets", "strict", "hybrid"], default="ets",
                        help="调度算法类型")

    # 带宽与列表参数 (支持传入多个值)
    parser.add_argument("-b", "--tc-bw", type=int, nargs="+", required=True,
                        help="每个 TC 的权重百分比列表，例如: --tc-bw 50 30 20 0")
    parser.add_argument("-s", "--strict-tcs", type=int, nargs="*", default=[],
                        help="混合模式下设置为 Strict 模式的 TC ID 列表，例如: --strict-tcs 3")
    parser.add_argument("-m", "--max-rates", type=int, nargs="*", default=[],
                        help="每个 TC 的限速 Kbps 列表(0表示不限制)，例如: --max-rates 100000 0 0 0")

    # DCB APP 绑定参数
    parser.add_argument("-p", "--prio", type=int, required=True, help="Priority/PCP (0-7)")
    parser.add_argument("-d", "--dscp", type=int, required=True, help="DSCP (0-63)")

    args = parser.parse_args()

    # ---- 参数合法性校验 ----
    if len(args.tc_bw) != args.num_tcs:
        sys.exit(f"[错误] 带宽参数 `--tc-bw` 的个数 ({len(args.tc_bw)}) 必须等于 `--num-tcs` ({args.num_tcs})")

    strict_set = set(args.strict_tcs)
    algo_enum = EtsAlgorithm(args.algo)

    # 校验 Strict TC ID 是否合法
    for tc_id in strict_set:
        if tc_id >= args.num_tcs or tc_id < 0:
            sys.exit(f"[错误] Strict TC ID ({tc_id}) 超出了设置的 TC 范围 (0~{args.num_tcs - 1})")

    # 校验 ETS 带宽和
    if algo_enum in (EtsAlgorithm.ETS, EtsAlgorithm.HYBRID):
        ets_bw_sum = sum(bw for i, bw in enumerate(args.tc_bw) if i not in strict_set)
        if ets_bw_sum != 100:
            sys.exit(f"[错误] 所有 ETS 模式下 TC 的带宽比例总和必须等于 100% (当前总和: {ets_bw_sum}%)")

    # 处理 max_rates 默认值补充
    max_rates = args.max_rates if args.max_rates else [0] * args.num_tcs
    if len(max_rates) != args.num_tcs:
        sys.exit(f"[错误] 限速参数 `--max-rates` 的个数 ({len(max_rates)}) 必须等于 `--num-tcs` ({args.num_tcs})")

    # 生成 TcConfig 列表
    tc_configs = []
    for tc_id in range(args.num_tcs):
        is_strict = (algo_enum == EtsAlgorithm.STRICT) or (tc_id in strict_set)
        tc_configs.append(
            TcConfig(
                tc_id=tc_id,
                weight=0 if is_strict else args.tc_bw[tc_id],
                is_strict=is_strict,
                max_rate_kbps=max_rates[tc_id]
            )
        )

    return args.ifname, algo_enum, tc_configs, args.prio, args.dscp


if __name__ == "__main__":
    ifname, algo, tc_configs, prio, dscp = parse_and_validate_args()

    manager = LinuxDcbCmdManager(ifname)
    success = manager.apply_dcb_configuration(algo, tc_configs, prio, dscp)

    sys.exit(0 if success else 1)


class ScriptBaseTxSchedCosTest(ScriptBase):
    # 测试机业务ip
    server_ip, client_ip = CommonOperation.get_nic_logical_ip()
    # 指令执行端
    exec_address = CmdExecuteAdressEnum.SERVER.value
    exec_address_other = CmdExecuteAdressEnum.CLIENT.value
    do_step = 1
    post_step = 1

    @classmethod
    def set_parameters(cls) -> None:
        """
        author:      weiyuan1
        date:        2026.09.07
        description: 设置配置环境需要的参数
        """
        super().set_parameters()
        cls.test_object = 'nic'
        cls.test_module = 'driver'
        cls.test_tool = ''
        cls.test_precondition = ''

    # ---------------------------------------------------------------------
    # dcb ets 修改 tc 便捷入口：供用例 do() 直接调用
    # ---------------------------------------------------------------------
    @classmethod
    def _dcb_manager(cls, ifname: str, cmd_execute_address: str = None) -> LinuxDcbCmdManager:
        return LinuxDcbCmdManager(ifname, cmd_execute_address or cls.exec_address)

    @classmethod
    def dcb_ets_modify_tc(cls, ifname: str, algo: EtsAlgorithm, tc_configs: list[TcConfig],
                          prio: int, dscp: int, cmd_execute_address: str = None) -> bool:
        """步骤1/2/4/5/7/8 全流程：dcbx host ieee → 检查tc数 → ets带宽 → 查询校验 → 限速 → prio/dscp绑定"""
        return cls._dcb_manager(ifname, cmd_execute_address).apply_dcb_configuration(algo, tc_configs, prio, dscp)

    @classmethod
    def set_dcbx_host_ieee(cls, ifname: str, cmd_execute_address: str = None) -> bool:
        """步骤2：设置 dcbx host ieee"""
        return cls._dcb_manager(ifname, cmd_execute_address).set_dcbx_host_ieee()

    @classmethod
    def show_ets(cls, ifname: str, cmd_execute_address: str = None) -> str:
        """步骤5：查询 dcb ets show dev <ifname>，返回输出文本"""
        return cls._dcb_manager(ifname, cmd_execute_address).show_ets()

    @classmethod
    def get_max_supported_tcs(cls, ifname: str, cmd_execute_address: str = None) -> int:
        """步骤1：检查网卡支持的 tc 数量"""
        return cls._dcb_manager(ifname, cmd_execute_address).get_max_supported_tcs()

    @classmethod
    def set_tc_max_rate(cls, ifname: str, tc_id: int, max_rate_kbps: int,
                        cmd_execute_address: str = None) -> bool:
        """步骤7：对 tc 设置限速"""
        return cls._dcb_manager(ifname, cmd_execute_address).set_tc_max_rate(tc_id, max_rate_kbps)

    @classmethod
    def bind_priority_to_dscp(cls, ifname: str, prio: int, dscp: int,
                              cmd_execute_address: str = None) -> bool:
        """步骤8：tc app 绑定优先级与 tos(dscp)"""
        return cls._dcb_manager(ifname, cmd_execute_address).bind_priority_to_dscp(prio, dscp)
