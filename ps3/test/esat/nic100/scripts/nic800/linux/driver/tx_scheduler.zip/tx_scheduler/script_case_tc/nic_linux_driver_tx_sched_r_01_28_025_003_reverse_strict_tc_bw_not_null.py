#!/usr/bin/env python3
# -*- encoding=utf8 -*-

"""
case author:   weiyuan1
script author: weiyuan1
date:          2026.09.07
description:

case number:   nic_linux_driver_tx_sched_r_01_28_025_003
case title:    TC层_可靠性_反向测试_ets+strict类型tc时，设置strict的tc的 tc-bw不为空
check point:   ets+strict类型tc时，设置strict的tc的 tc-bw不为空
test condition:反向测试-非法/边界配置
test platform: 测试PF/VF；双机iperf3打流

@steps:
1. 检查网卡支持的tc数量
2. 设置dcbx host ieee（指令：dcb dcbx set dev <intf_name> host ieee）
3. 获取初始化状态tx_sched调度树tc 节点信息
4. dcb ets 设置ets+strict类型tc时，设置strict的tc的 tc-bw不为空
5. 清理环境

@steps expect result:
1. 获取网卡支持的tc数量成功
2. 设置dcbx成功
3. 获取tc节点信息成功
4. 命令执行失败
5. 清理环境成功

@changelog:

"""
import add_syspath

from scripts.script_libs import log
from scripts.nic800.linux.driver.tx_scheduler.script_base_tx_sched_cos_test import ScriptBaseTxSchedCosTest
from scripts.script_libs.common_operation import CommonOperation


class Script(ScriptBaseTxSchedCosTest):
    @classmethod
    def set_parameters(cls) -> None:
        """
        author: weiyuan1
        date: 2026.09.07
        descriptor: 设置需要调用的变量
        :return: 无返回值
        """
        super().set_parameters()

    @classmethod
    def check_own_environment(cls) -> None:
        """
        author: weiyuan1
        date: 2026.09.07
        descriptor: 检测当前脚本运行所需的局部环境是否具备，该方法只检测，不报bug,
                    函数内需要设定类变量local_enviroment_enabled的值，
                    局部环境检测正常，类变量local_enviroment_enabled设置为True
        :return: 无返回值
        """
        super().check_own_environment()
        log.info('脚本尚未实现，暂时跳过')
        cls.own_environment_enabled = False

    @classmethod
    def prepare(cls) -> None:
        """
        author: weiyuan1
        date: 2026.09.07
        descriptor: 准备环境
        :return: 无返回值
        """
        super().prepare()

    @classmethod
    def do(cls) -> None:
        """
        author: weiyuan1
        date: 2026.09.07
        descriptor: 执行测试环境
        :return: 无返回值
        """
        super().do()

        CommonOperation.concat_test_steps(

            'step1. 检查网卡支持的tc数量; expect result: 1. 获取网卡支持的tc数量成功')


        CommonOperation.concat_test_steps(

            'step2. 设置dcbx host ieee（指令：dcb dcbx set dev <intf_name> host ieee）; expect result: 2. 设置dcbx成功')


        CommonOperation.concat_test_steps(

            'step3. 获取初始化状态tx_sched调度树tc 节点信息; expect result: 3. 获取tc节点信息成功')


        CommonOperation.concat_test_steps(

            'step4. dcb ets 设置ets+strict类型tc时，设置strict的tc的 tc-bw不为空; expect result: 4. 命令执行失败')


        CommonOperation.concat_test_steps(

            'step5. 清理环境; expect result: 5. 清理环境成功')


    @classmethod
    def post(cls) -> None:
        """
        author: weiyuan1
        date: 2026.09.07
        descriptor: 整理环境及结果信息相关信息
        :return: 无返回值
        """
        super().post()


def main() -> None:
    Script.run()


if __name__ == "__main__":
    main()
